class Heap {
  // o maior elemento da subarvore da esquerda de um heap � o segundo elemento.
  int maior(int array[]) {
    return array[1];
  }
}